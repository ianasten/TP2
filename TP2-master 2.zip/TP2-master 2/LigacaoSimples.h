#ifndef LIGACAOSIMPLES_H_INCLUDED
#define LIGACAOSIMPLES_H_INCLUDED
#include "Ligacao.h"

using namespace std;

class LigacaoSimples: public Ligacao{
private:
    double _NumTelefone;
public:
    LigacaoSimples(Data dataHora, double duracao, double custo, double NumTelefone) :
        Ligacao(Data dataHora, double duracao, double custo), _NumTelefone(NumTelefone){}; //construtor
    ~LigacaoSimples(); //destrutor
};


#endif // LIGACAOSIMPLES_H_INCLUDED
