#ifndef POSPAGO_H_INCLUDED
#define POSPAGO_H_INCLUDED
#include "Plano.h"
#include "Data.h"
using namespace std;

class PosPago: public Plano{
private:
    Data _vencimento;
public:
    PosPago(string nome, double ValorMinuto, double Velocidade, double Franquia, double VelocAlem, Data vencimento) :
        Plano(string nome, double ValorMinuto, double Velocidade, double Franquia, double VelocAlem), _vencimento(vencimento){}; //construtor
    ~PosPago(): //destrutor

};


#endif // POS_PAGO_H_INCLUDED
