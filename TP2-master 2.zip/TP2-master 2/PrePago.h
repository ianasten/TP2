#ifndef PREPAGO_H_INCLUDED
#define PREPAGO_H_INCLUDED
#include"Plano.h"
using namespace std;

class PrePago: public Plano{
private:
    double _credito;
    Date _validade;
public:

};


#endif // PRE_PAGO_H_INCLUDED
