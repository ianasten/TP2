#ifndef POSPAGO_H_INCLUDED
#define POSPAGO_H_INCLUDED
#include"Plano.h"
using namespace std;

class PosPago: public Plano{
private:
    Date _vencimento;
public:


};


#endif // POS_PAGO_H_INCLUDED
