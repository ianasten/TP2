#ifndef LIGACAODADOS_H_INCLUDED
#define LIGACAODADOS_H_INCLUDED
#include"Ligacao.h"
using namespace std;

class LigacaoDados: public Ligacao{
private:
    Enum TipoDados _tipo;
public:
    Enum TipoDados{Download = 0, Upload = 1}; //n�o sei
    LigacaoDados(Data dataHora, double duracao, double custo, TipoDados tipo) :
        Ligacao(Data dataHora, double duracao, double custo), _tipo(tipo){};
    ~LigacaoDados();
};


#endif // LIGACAODADOS_H_INCLUDED
