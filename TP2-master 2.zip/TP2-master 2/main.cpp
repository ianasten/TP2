#include <iostream>
#include "Cliente.h"
#include "Celular.h"
#include "Ligacao.h"
#include "LigacaoDados.h"
#include "LigacaoSimples.h"
//#include "Plano.h"
//#include "Pos_Pago.h"
//#include "Pre_Pago.h"
#include "Data.h"

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
