#ifndef LIGACAO_H_INCLUDED
#define LIGACAO_H_INCLUDED
#include "Data.h"
using namespace std;

class Ligacao{
private:
    Data _dataHora;
    double _duracao; // em minutos
    double _custo;
public:
	Ligacao(Data dataHora, double duracao, double custo) : _dataHora(dataHora), _duracao(duracao), _custo(custo){}; // construtor
	~Ligacao(); // destrutor
	const Data get_data(){ return _dataHora; };
	const double get_duracao(){ return _duracao; };
	const double get_custo(){ return _custo; };
	void set_Data(Date dataHora) : _dataHora(dataHora){};
	void set_duracao(double duracao) : _duracao(duracao){};
	void set_custo(double custo) : _custo(custo){};

};


#endif // LIGACAO_H_INCLUDED
