#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED
#include <iostream>
using namespace std;


class Data{
private:
    int _dia;
    int _mes;
    int _ano;
    string _data;
public:
    Data(int dia, int mes, int ano) : _dia(dia), _mes(mes), _ano(ano){};
    ~Data(){}; //falta o cpp
    string get_data() {return _data;};
    void imprimi_data(){ _data = _dia.str()+"/" + _mes.str()+"/"+ _ano.str(); cout << _data << endl; }
    int get_dia() {return _dia;};
    int get_mes() {return _mes;};
    int get_ano() {return _ano;};
    void set_dia(int dia) : _dia(dia){};
    void set_mes(int mes) : _mes(mes){};
    void set_ano(int ano) : _ano(ano){};
    void set_data(string data) : _data(data){};
};

#endif // DATA_H_INCLUDED
