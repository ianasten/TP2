#ifndef PREPAGO_H_INCLUDED
#define PREPAGO_H_INCLUDED
#include "Plano.h"
#include "Data.h"
using namespace std;

class PrePago: public Plano{
private:
    double _credito;
    Data _validade;
public:
    PrePago(string nome, double ValorMinuto, double Velocidade, double Franquia, double VelocAlem, double credito, Data validade) :
        Plano(string nome, double ValorMinuto, double Velocidade, double Franquia, double VelocAlem), _credito(credito), _validade(validade){}; //construtor
    ~PrePago(); //destrutor
    void adiciona_credito(Celular numero, double creditos){};

};


#endif // PRE_PAGO_H_INCLUDED
