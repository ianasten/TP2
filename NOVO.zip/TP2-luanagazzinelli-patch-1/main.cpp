#include <iostream>
#include<string>
class Cliente;
class Celular;
class Ligacao;
class LigacaoDados;
class LigacaoSimples;
class Plano;
class PosPago;
class PrePago;
class Data;

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
