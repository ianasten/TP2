#ifndef LIGACAODADOS_H_INCLUDED
#define LIGACAODADOS_H_INCLUDED
class Ligacao;
class Data;
using namespace std;

/*enum TipoDados{
    Upload,
    Download};

class LigacaoDados: public Ligacao{
private:
    TipoDados _tipo;
public:
    LigacaoDados(Data* dataHora, double duracao, double custo, TipoDados tipo) {Ligacao(dataHora, duracao, custo); _tipo=tipo;}
    ~LigacaoDados();



    };
*/

#endif // LIGACAODADOS_H_INCLUDED
