#ifndef LIGACAOSIMPLES_H_INCLUDED
#define LIGACAOSIMPLES_H_INCLUDED
class Ligacao;
class Data;
using namespace std;

/*class LigacaoSimples: public Ligacao{
private:
    double _NumTelefone;
public:
    LigacaoSimples(Data* dataHora, double duracao, double custo, double NumTelefone){Ligacao(dataHora, duracao, custo); _NumTelefone=NumTelefone;}
    ~LigacaoSimples();
};

*/


#endif // LIGACAOSIMPLES_H_INCLUDED
